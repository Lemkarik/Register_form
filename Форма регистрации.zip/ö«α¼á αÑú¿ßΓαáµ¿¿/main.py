from flask import Flask
from data import db_session
from data.users import User
from flask_login import LoginManager, UserMixin
from flask_wtf import FlaskForm
from wtforms import PasswordField, StringField, TextAreaField, SubmitField, BooleanField
from wtforms.fields.html5 import EmailField
from wtforms.validators import DataRequired

app = Flask(__name__)
login_manager = LoginManager()
login_manager.init_app(app)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)


class LoginForm(FlaskForm):
    email = EmailField('Почта', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    remember_me = BooleanField('Запомнить меня')
    submit = SubmitField('Войти')


def main():
    db_session.global_init("db/users.db")
    users = [
        {'surname': 'Scott',
         'name': 'Ridley',
         'age': 21,
         'position': 'captain',
         'speciality': 'research engineer',
         'address': 'module_1',
         'email': 'scott_chief@mars.org'},
        {'surname': 'Smith',
         'name': 'John',
         'age': 23,
         'position': 'doctor',
         'speciality': 'everything',
         'address': 'module_3',
         'email': 'usualhuman@mars.org'},
        {'surname': 'Krolik',
         'name': 'Krosh',
         'age': 12,
         'position': 'balamut',
         'speciality': 'obormot',
         'address': 'module_5',
         'email': 'krosh@mars.org'},
        {'surname': 'Hedgehog',
         'name': 'Yozhik',
         'age': 9,
         'position': 'scientist',
         'speciality': 'cactusology',
         'address': 'module_6',
         'email': 'yozhik@mars.org'},
    ]
    db_sess = db_session.create_session()
    for i in users:
        user = User()
        user.surname = i['surname']
        user.name = i['name']
        user.age = i['age']
        user.position = i['position']
        user.speciality = i['speciality']
        user.address = i['address']
        user.email = i['email']
        db_sess.add(user)
    db_sess.commit()
    app.run()


if __name__ == '__main__':
    main()
