from flask import Flask, render_template, url_for, request
from data import db_session
from data.jobs import Jobs
from data.users import User
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField, IntegerField
from wtforms.validators import DataRequired


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


class RegisterForm(FlaskForm):
    username = StringField('Login/email', validators=[DataRequired()])
    password = StringField('Password', validators=[DataRequired()])
    repeat_password = StringField('Repeat password', validators=[DataRequired()])
    surname = StringField('Surname', validators=[DataRequired()])
    name = StringField('Name', validators=[DataRequired()])
    age = IntegerField('Age', validators=[DataRequired()])
    position = StringField('Position', validators=[DataRequired()])
    speciality = StringField('Speciality', validators=[DataRequired()])
    address = StringField('Address', validators=[DataRequired()])
    submit = SubmitField('Submit')


@app.route('/', methods=['POST', 'GET'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        db_session.global_init('db/users.db')
        db_sess = db_session.create_session()
        new_user = User()
        new_user.surname = form.surname.data
        new_user.name = form.name.data
        new_user.age = form.age.data
        new_user.position = form.position.data
        new_user.speciality = form.speciality.data
        new_user.address = form.address.data
        new_user.email = form.username.data
        new_user.hashed_password = hash(form.address.data)
        db_sess.add(new_user)
        db_sess.commit()
        return 'Форма отправлена'
    return render_template('register.html', title='Авторизация', form=form)



if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')